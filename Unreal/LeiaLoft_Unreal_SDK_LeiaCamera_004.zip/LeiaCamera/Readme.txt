To add the LeiaLoft Unreal SDK's LeiaCamera plugin to your UE project, place this LeiaCamera folder at this location in your UE project:

<UE_project>/Plugins/LeiaCamera
