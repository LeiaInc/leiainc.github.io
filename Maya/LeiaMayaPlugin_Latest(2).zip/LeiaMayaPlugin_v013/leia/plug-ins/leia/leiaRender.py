
import platform
import os
import shutil
import subprocess
import time
import sys
import traceback

from PySide2 import QtGui, QtCore, QtWidgets
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from shiboken2 import wrapInstance

import maya.cmds as mc
import maya.mel as mel
import maya.utils
from maya import OpenMayaUI as omui

import SystemTools

class LeiaRender:
    def __init__(self):
        self.batchRenderWindow = None
        CWD = os.path.abspath(os.path.dirname(__file__))
        self.scriptUtilsPath = CWD + os.sep + "helper_scripts" + os.sep

        # Set the script extension to bat or sh
        if platform.system() is 'Windows':
            self.isShellProc = True
            self.scriptExt = 'bat'
        else:
            self.isShellProc = False
            self.scriptExt = 'sh'

        self.startFrame = mc.getAttr("defaultRenderGlobals.startFrame")
        self.endFrame = mc.getAttr("defaultRenderGlobals.endFrame")

    def setArnoldRenderSetting(self,
                               startFrame,
                               endFrame,
                               width,
                               height):
        try:
            # Source: https://github.com/aaibfer/mtoaUtils/blob/ac2b56ecae3a56ea0e02823d9bf38c9ee6e6dbe6/scripts/aiSettings.py
            if not mc.pluginInfo("mtoa", query=True, loaded=True):
                mc.loadPlugin("mtoa", quiet=True)
                mc.setAttr("defaultRenderGlobals.currentRenderer", l=False)
                mc.setAttr("defaultRenderGlobals.currentRenderer", "arnold", type="string")

            if not mc.objExists("defaultArnoldDriver"):
                mc.createNode("aiAOVDriver", name=":defaultArnoldDriver", skipSelect=True, shared=True)

            if not mc.objExists("defaultArnoldRenderOptions"):
                mc.createNode("aiOptions", name=":defaultArnoldRenderOptions", skipSelect=True, shared=True)

            if not mc.objExists("defaultArnoldDisplayDriver"):
                mc.createNode("aiAOVDriver", name=":defaultArnoldDisplayDriver", skipSelect=True, shared=True)
                mc.connectAttr("defaultArnoldDisplayDriver.message", "defaultArnoldRenderOptions.drivers", nextAvailable=True)

            # First we disable additional render passes
            if mc.getAttr("defaultArnoldRenderOptions.aovMode") == 1:
                mc.setAttr("defaultArnoldRenderOptions.aovMode", 0)

            device_aspect = float(width)/float(height)
            mc.setAttr("defaultResolution.lockDeviceAspectRatio", 1)
            mc.setAttr("defaultResolution.deviceAspectRatio", device_aspect)

            mc.setAttr("defaultResolution.width", int(width))
            mc.setAttr("defaultResolution.height", int(height))

            mc.setAttr("defaultArnoldDriver.aiTranslator", "png", type="string")
            mc.setAttr("defaultRenderGlobals.imageFormat", 32)
            mc.setAttr('defaultRenderGlobals.imageFilePrefix', "<Scene>" + os.sep + "<RenderLayer>"
                       + os.path.sep + "<Camera>" + os.sep + "v", type="string")
            mc.setAttr('defaultRenderGlobals.putFrameBeforeExt', True)
            mc.setAttr('defaultRenderGlobals.animation', True)
            mc.setAttr('defaultRenderGlobals.extensionPadding', 7)
            mc.setAttr('defaultRenderGlobals.startFrame', startFrame)
            mc.setAttr('defaultRenderGlobals.endFrame', endFrame)

            # Set active Render Layer to the default masterLayer
            mc.eval('editRenderLayerGlobals -currentRenderLayer defaultRenderLayer')

        except Exception as e:
            print('Leia Plugin: Error while applying Arnold renderer settings. ', e)


    def getLeiaCameraResolution(self, cam):
        # Get parent landscape/portrait state for rendering
        leiaCameraParent = mc.listRelatives(cam, parent=True)
        leiaCameraParent = mc.listRelatives(leiaCameraParent, parent=True)
        isInLandscape = mc.getAttr(str(leiaCameraParent[0]) + '.landscapeBounds')

        if isInLandscape:
            width = 640
            height = 360
        else:
            width = 360
            height = 640

        return width, height


    def pushRendersToAndroid(self, render_list=[]):

        push_script_path = self.scriptUtilsPath + "push_to_android." + self.scriptExt
        gMainProgressBar = maya.mel.eval('$tmp = $gMainProgressBar')

        mc.progressBar(
            gMainProgressBar,
            maxValue=len(render_list) + 1,
            edit=True,
            beginProgress=True,
            isInterruptable=True,
            status='Copying renders to your Android device...'
            )

        out = ""

        for render_path in render_list:

            push_params = [push_script_path, str(os.path.expanduser(render_path))]

            pushProc = subprocess.Popen(
                push_params,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False
            )

            if pushProc.poll() is None:
                out, err = pushProc.communicate()
                del pushProc
                print out, err

                if "no devices/emulators found" in out:
                    mc.confirmDialog(message="Please ensure your Android device is connected.")
                    break

            mc.progressBar(gMainProgressBar, edit=True, step=1)

        if "100%" in out:
            mc.confirmDialog(message="Successfully pushed to your Android Devices's Downloads folder.")

        mc.progressBar(gMainProgressBar, edit=True, endProgress=True)

    def mergeImgDirToVideo(self, dir, startFrame=0):
        shellCmd = self.scriptUtilsPath + "merge_renders." + self.scriptExt

        mergeImageCmd = [shellCmd, os.path.expanduser(dir), str(startFrame)]

        SystemTools.runCommand(command=mergeImageCmd, asShell=self.isShellProc)

        # TODO: get video output name from the merger shell script
        outputVideo = dir + '/view.mp4'

        return outputVideo

    def create2x2Image(self, output, view1, view2, view3, view4):
        IMAGE1 = QImage()
        IMAGE1.load(view1)
        IMAGE2 = QImage()
        IMAGE2.load(view2)
        IMAGE3 = QImage()
        IMAGE3.load(view3)
        IMAGE4 = QImage()
        IMAGE4.load(view4)

        pm1 = QtGui.QPixmap(IMAGE1)
        pm2 = QtGui.QPixmap(IMAGE2)
        pm3 = QtGui.QPixmap(IMAGE3)
        pm4 = QtGui.QPixmap(IMAGE4)

        width = IMAGE1.width()
        height = IMAGE1.height()
        quad_image = QtGui.QPixmap(width * 2, height * 2)

        top_l = QtCore.QRectF(0, 0, width, height)
        top_r = QtCore.QRectF(width, 0, width, height)
        bot_l = QtCore.QRectF(0, height, width, height)
        bot_r = QtCore.QRectF(width, height, width, height)

        painter = QtGui.QPainter(quad_image)
        painter.drawPixmap(top_l, pm1, QtCore.QRectF(pm1.rect()))
        painter.drawPixmap(top_r, pm2, QtCore.QRectF(pm2.rect()))
        painter.drawPixmap(bot_l, pm3, QtCore.QRectF(pm3.rect()))
        painter.drawPixmap(bot_r, pm4, QtCore.QRectF(pm4.rect()))
        painter.end()

        mc.refresh()
        maya.utils.processIdleEvents()

        if quad_image.save(output, format='jpg', quality=100):
            print('LeiaPlugin: Image saved to ', str(output))
            QPixmapCache.clear()
        else:
            print('Leia Plugin: Failed to save a frame, ', output)
            output = None

        QPixmapCache.clear()
        return output

    def openFileExplorer(self, path):

        if sys.platform == 'darwin':
            subprocess.check_call(['open', '--', path])
        elif sys.platform == 'linux2':
            subprocess.check_call(['xdg-open', '--', path])
        elif sys.platform == 'win32':
            try:
                subprocess.check_call(['explorer', (path).replace('/', '\\')])
            except:
                pass


    def render(self, startFrame=0, endFrame=1, outputVideo=False, openFileExplorer=False, pushToAndroid=False):

        if (endFrame - startFrame) + 1 > 0 and startFrame >= 0 and endFrame > 0:

            renderFailed = False

            # Set the file type and dependent file location
            if outputVideo:
                outputDir = 'movies/'
                fileExt = '.mp4'
            else:
                outputDir = 'images/'
                fileExt = '_2x2.jpg'

            gMainProgressBar = maya.mel.eval('$tmp = $gMainProgressBar')

            try:

                # First we'll find all leia cameras to render
                leiaCameras = mc.ls('*LeiaCamera*_view*', cameras=True, visible=True)
                leiaCameraCount = len(leiaCameras)
                leiaCameraRigCount = (leiaCameraCount // 4)

                if leiaCameraRigCount > 0:

                    # Setup paths and names used for rendering path name
                    projectDirectory = mc.workspace(q=True, rd=True)

                    filepath = mc.file(q=True, sn=True)
                    filename = os.path.basename(filepath)
                    sceneName, extension = os.path.splitext(filename)

                    # Handle rendering in untitled scenes because, thankfully, Maya does not.
                    if sceneName == '':
                        sceneName = 'untitled'

                    renderLayer = 'masterLayer'

                    # TODO: path join this shit
                    viewsRenderDir = projectDirectory + 'images/' + sceneName + '/' + renderLayer + '/'

                    renderPath = projectDirectory + outputDir + sceneName

                    # Clear previous render, TODO: reuse rendererd data
                    if os.path.exists(viewsRenderDir):
                        shutil.rmtree(viewsRenderDir)

                    # Start rendering progress bar
                    mc.progressBar(gMainProgressBar,
                                     maxValue=leiaCameraCount + 1,
                                     edit=True,
                                     beginProgress=True,
                                     isInterruptable=True,
                                     status='Batch Rendering Leia Cameras...'
                                   )



                    #
                    # Render each Leia Camera
                    #
                    for cam in leiaCameras:

                        mc.progressBar(gMainProgressBar, edit=True, step=1)

                        if mc.progressBar(gMainProgressBar, query=True, isCancelled=True):
                            print("Stopping Leia Batch Render...")
                            mc.progressBar(gMainProgressBar, edit=True, endProgress=True)
                            return

                        # Set render properties
                        width, height = self.getLeiaCameraResolution(cam)

                        # TODO: Remove redundant call
                        try:
                            self.setArnoldRenderSetting(width=width, height=height, startFrame=startFrame, endFrame=endFrame)
                        except:
                            # Call setup twice as an Arnold bug work around.
                            self.setArnoldRenderSetting(width=width, height=height, startFrame=startFrame, endFrame=endFrame)

                        # Refresh maya ui and process any cancel event
                        mc.refresh()
                        maya.utils.processIdleEvents()

                        mc.arnoldRender(cam=cam, width=width, height=height, batch=True)



                    #
                    # Find and process rendered files
                    #
                    leiaViewVideos = []
                    leiaViewImages = []

                    for renderDir in sorted(os.listdir(viewsRenderDir)):

                        if 'Leia' not in renderDir:
                            break

                        # Generate videos of each view
                        if outputVideo is True:

                            # Create video of all views
                            imgRendersDir = viewsRenderDir + renderDir

                            video = self.mergeImgDirToVideo(dir=imgRendersDir, startFrame=startFrame)

                            leiaViewVideos.append(os.path.expanduser(video))

                            if len(leiaViewVideos) <= 0:
                                renderFailed = True


                        # Or we generate a sorted list of images for combining later.
                        else:

                            sortedImageRenders = []

                            for filePath in sorted(os.listdir(viewsRenderDir + renderDir)):
                                if 'png' in filePath:
                                    sortedImageRenders.append(viewsRenderDir + renderDir + '/' + filePath)

                            leiaViewImages.append(sortedImageRenders)

                            if len(sortedImageRenders) <= 0:
                                renderFailed = True


                    if renderFailed:
                        mc.confirmDialog(
                            message="Rendering failed, please verify Arnold is working properly and try again.")
                        return

                    outputRenderPaths = []

                    #
                    # Create 2x2 Videos or 2x2 Images
                    #
                    if outputVideo is True:

                        shellCmd = self.scriptUtilsPath + "create_2x2." + self.scriptExt
                        curTime = time.strftime("%Y-%m-%d_%H.%M.%S")

                        for i in range(len(leiaViewVideos)):

                            fourViewVideoFile = renderPath + "_" + str(leiaCameraRigCount) + "_" + curTime + fileExt

                            if i % 4 == 0:
                                leiaCameraRigCount -= 1
                                create4vCmd = [shellCmd,
                                               leiaViewVideos[i],
                                               leiaViewVideos[i + 1],
                                               leiaViewVideos[i + 2],
                                               leiaViewVideos[i + 3],
                                               fourViewVideoFile]

                                SystemTools.runCommand(command=create4vCmd, asShell=self.isShellProc)

                                outputRenderPaths.append(fourViewVideoFile)

                    else:

                        # Prepare the list of images for creating 2x2s
                        quadImagesPairs = []
                        for i in range(len(leiaViewImages) // 4):

                            for j in range(len(leiaViewImages[0])):
                                quad = []
                                quad.append(leiaViewImages[(i * 4) + 0][j])
                                quad.append(leiaViewImages[(i * 4) + 1][j])
                                quad.append(leiaViewImages[(i * 4) + 2][j])
                                quad.append(leiaViewImages[(i * 4) + 3][j])

                                quadImagesPairs.append(quad)


                        # Combine the 4 images in the list into 2x2s
                        frameNumber = 0
                        curTime = time.strftime("%Y-%m-%d_%H.%M.%S")

                        for views in quadImagesPairs:

                            frameNumber += 1
                            outputImage = renderPath + "_" + str(frameNumber) + "_" + curTime + fileExt

                            outputImagePath = self.create2x2Image(output=outputImage,
                                                view1=views[0],
                                                view2=views[1],
                                                view3=views[2],
                                                view4=views[3])

                            if outputImagePath is not None:
                                outputRenderPaths.append(outputImagePath)


                    # End progress bar
                    mc.progressBar(gMainProgressBar, edit=True, step=1)
                    mc.progressBar(gMainProgressBar, edit=True, endProgress=True)

                    # Open file explorer
                    if openFileExplorer is True:
                        self.openFileExplorer(projectDirectory + outputDir)

                    # Push to Android
                    if pushToAndroid is True:
                        self.pushRendersToAndroid(outputRenderPaths)

                else:
                    mc.confirmDialog(message="Please ensure a LeiaCamera rig exists.")

            except Exception as e: #TODO: Handle exceptions properly.
                traceback.print_exc()
                mc.confirmDialog(message="Leia Plugin: Error caught while rendering.\n\n" + str(e))
                mc.progressBar(gMainProgressBar, edit=True, endProgress=True)
                print('Leia Plugin: An error was thrown while rendering. ', e)

        else:
            mc.confirmDialog(message="Please enter a frame range containing at least 1 frame.")


leia_render = LeiaRender()

def showBatchRenderPrompt():

    global leia_render

    if leia_render.batchRenderWindow is not None:
        leia_render.batchRenderWindow.close()
        leia_render.batchRenderWindow.deleteLater()

    maya_main_window_ptr = omui.MQtUtil.mainWindow()
    maya_main_window = wrapInstance(long(maya_main_window_ptr), QWidget)

    leia_render.batchRenderWindow = QMainWindow(maya_main_window)
    leia_render.batchRenderWindow.setWindowFlags(Qt.Tool)

    main_width = 300
    main_height = 250

    leia_render.batchRenderWindow.resize(main_width, main_height)

    centralwidget = QWidget(leia_render.batchRenderWindow)
    centralwidget.resize(main_width, main_height)

    start_frame_label = QLabel("Start Frame:", centralwidget)
    end_frame_label = QLabel("End Frame:", centralwidget)

    warning_label = QLabel("Warning, this process cannot be stopped.", leia_render.batchRenderWindow)
    warning_label.setWordWrap(True)
    warning_label.setStyleSheet('QLabel {color: #660000;}')
    output_label = QLabel("Output Format:", centralwidget)

    start_edit = QLineEdit(str(int(leia_render.startFrame)), centralwidget)
    end_edit = QLineEdit(str(int(leia_render.endFrame)), centralwidget)
    mp4_radio = QRadioButton("MP4", leia_render.batchRenderWindow)
    png_radio = QRadioButton("PNG", leia_render.batchRenderWindow)

    open_folder = QCheckBox("Open result in file explorer", centralwidget)
    push_to_android = QCheckBox("Copy to Android Device", centralwidget)

    start_button = QPushButton("Start", centralwidget)

    batch_group = QGroupBox("Batch Render Leia Cameras", centralwidget)
    batch_group.resize(main_width, main_height)
    fl = QGridLayout(batch_group)

    fl.addWidget(start_frame_label, 1, 0)
    fl.addWidget(start_edit, 1, 1)
    fl.addWidget(end_frame_label, 2, 0)
    fl.addWidget(end_edit, 2, 1)
    fl.addWidget(output_label, 3, 0)
    fl.addWidget(mp4_radio, 3, 1)
    fl.addWidget(png_radio, 4, 1)
    fl.addWidget(open_folder, 5, 1)
    fl.addWidget(push_to_android, 6, 1)
    fl.addWidget(warning_label, 8, 0)
    fl.addWidget(start_button, 8, 1)
    png_radio.toggle()

    start_button.clicked.connect(
        lambda: (
            leia_render.render(
                startFrame=int(start_edit.text()),
                endFrame=(int(end_edit.text()) - 1),
                outputVideo=mp4_radio.isChecked(),
                openFileExplorer=open_folder.isChecked(),
                pushToAndroid=push_to_android.isChecked()
            )
        )
    )

    leia_render.batchRenderWindow.show()