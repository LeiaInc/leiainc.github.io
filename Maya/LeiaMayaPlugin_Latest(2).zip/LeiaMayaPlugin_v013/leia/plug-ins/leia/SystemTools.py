import platform
import os
import subprocess

def IsWindows():
    if "Windows" == platform.system():
        return True
    else:
        return False

def AddToSysPath(path):
    if path not in os.environ["PATH"]:
        os.environ["PATH"] += os.pathsep + path

def GetExecutablesPath(executable):

    if IsWindows():
        executable += ".exe"
    else:
        AddToSysPath("/usr/local/bin/")

    if "PATH" in os.environ:

        envPath = os.environ["PATH"].split(os.pathsep)

        for line in envPath:
            if os.path.exists(line):

                for binary in os.listdir(line):
                    if executable == binary:
                        return os.path.join(line, executable)

    return None


def runCommand(command, asShell=True):
    if command is not "":
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                shell=asShell)

        if proc.poll() is None:
            out, err = proc.communicate()
            del proc

            print out, err
