#!/bin/bash

input=$1
file_base=`basename $input`
dest_dir='/sdcard/Download/'


[[ ":$PATH:" != *":/usr/local/bin:"* ]] && PATH="/usr/local/bin:${PATH}"

for i in ${PATH//:/ }; do
    # Search path folder for adb
    adb=`find -L "$i" -type f -perm -a=x -name 'adb' -print -quit 2>/dev/null`

    # Found adb in path var
    if [ "${adb}" != "" ]; then
        break
    fi
done

#Push the render to the folder
$adb push $input "$dest_dir"
