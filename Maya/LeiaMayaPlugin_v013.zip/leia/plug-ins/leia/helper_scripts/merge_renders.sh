#!/bin/bash

input=$1
start_frame=$2

ffmpeg=`find -L / -type f -perm -a=x -name 'ffmpeg' -print -quit 2>/dev/null`

$ffmpeg -r 24 -start_number $start_frame -i "$input"/v.%07d.png -c:v libx264 -vf "fps=24,format=yuv420p" -crf 16 -maxrate 18M -bufsize 10M -f mp4 "$input"/view.mp4 -y
