#!/bin/bash

v1=$1
v2=$2
v3=$3
v4=$4
output=$5


[[ ":$PATH:" != *":/usr/local/bin:"* ]] && PATH="/usr/local/bin:${PATH}"

for i in ${PATH//:/ }; do
    # Search path folder for ffmpeg
    ffmpeg=`find -L "$i" -type f -perm -a=x -name 'ffmpeg' -print -quit 2>/dev/null`

    # Found ffmpeg in path var
    if [ "${ffmpeg}" != "" ]; then
        break
    fi

done



$ffmpeg -y -i $v1 -i $v2 -i $v3 -i $v4 -filter_complex "[0:v][1:v]hstack[t];[2:v][3:v]hstack[b];[t][b]vstack[v]" -map "[v]" -crf 17 -maxrate 18M -bufsize 10M -pix_fmt yuv420p -c:a copy -metadata comment="leia3d_layout=2x2;leia3d_disparity_shift=0;leia3d_disparity_scale=1;" "$output"
