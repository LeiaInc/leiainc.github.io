
import maya.cmds as mc

def getCurrentResolution( ):
	return(mc.getAttr("defaultResolution.width"), mc.getAttr("defaultResolution.height"))